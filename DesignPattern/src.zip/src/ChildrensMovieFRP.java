/**
 * Group Project member
 * Wesley Axline WJA200000
 * Christian Thomas CXT180023
 * Reevan Mathews RXM180076
 */

public class ChildrensMovieFRP implements FRPStrategy {

    public int calcFRP(int FRP) {
        FRP +=1;
        return FRP;
    }
    public int daysRented() {
        return 0;
    }
}