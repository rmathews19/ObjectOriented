/**
 * Group Project member
 * Wesley Axline WJA200000
 * Christian Thomas CXT180023
 * Reevan Mathews RXM180076
 */

public interface FRPStrategy {
    public int calcFRP(int FRP);
    public int daysRented();
}
